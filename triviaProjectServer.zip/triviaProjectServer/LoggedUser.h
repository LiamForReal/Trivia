#pragma once
#include "includes.h"

class LoggedUser
{
public:
	LoggedUser(string name);
	string getUserName() const;
private:
	string username;
};

