#pragma once
#include "IRequestHandler.h"

class Communicator
{
public:
	void handleNewClient(const RequestInfo& requestInfo);
};

