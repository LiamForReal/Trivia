#include "LoginRequestHandler.h"

bool LoginRequestHandler::isRequestRelevant(const RequestInfo& requestInfo)
{
	return requestInfo.id == LOGIN_RC;
}
RequestResult LoginRequestHandler::handleRequest(const RequestInfo& requestInfo)
{
	LoginRequest lr = JsonRequestPacketDeserializer::deserializeLoginRequest(requestInfo.buffer);
	RequestResult rr = RequestResult();
	rr.buffer = requestInfo.buffer;
	//rr.newHandler = this; // ?
	return rr;
}