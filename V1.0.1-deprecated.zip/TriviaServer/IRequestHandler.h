#pragma once
class IRequestHandler
{

};